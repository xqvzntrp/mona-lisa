@echo off
setlocal
cd /d "%~dp0"
java CheckProjectWiring.java
if errorlevel 1 pause & exit /b %errorlevel%
pause
