﻿@echo off
setlocal
cd /d "%~dp0"
if not exist "target\env05-template-1.0-SNAPSHOT.jar" (
    echo Notes Forms App is not built yet.
    echo Run BuildNotesFormsApp.cmd first.
    pause
    exit /b 1
)
start "" javaw -jar target\env05-template-1.0-SNAPSHOT.jar

