import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class CheckProjectWiring {
    private CheckProjectWiring() {
    }

    public static void main(String[] args) throws Exception {
        Path root = Path.of("").toAbsolutePath().normalize();
        List<String> errors = new ArrayList<>();

        require(root.resolve("pom.xml"), errors);
        require(root.resolve("RunNotesFormsApp.cmd"), errors);
        require(root.resolve("BuildNotesFormsApp.cmd"), errors);
        require(root.resolve("src/main/java/NotesFormsApp.java"), errors);
        require(root.resolve("docs/master-detail-pattern.md"), errors);

        checkTextContains(root.resolve("pom.xml"), "<mainClass>NotesFormsApp</mainClass>", errors);
        checkTextContains(root.resolve("RunNotesFormsApp.cmd"), "target\\env05-template-1.0-SNAPSHOT.jar", errors);
        checkTextContains(root.resolve("BuildNotesFormsApp.cmd"), "mvn clean install", errors);

        checkPlan(root, root.resolve("run-plan.csv"), errors);
        checkPlan(root, root.resolve("backup-plan.csv"), errors);

        if (!errors.isEmpty()) {
            System.err.println("Project wiring check failed:");
            for (String error : errors) {
                System.err.println("- " + error);
            }
            System.exit(1);
        }

        System.out.println("Project wiring check OK");
    }

    private static void checkPlan(Path root, Path plan, List<String> errors) throws Exception {
        require(plan, errors);
        if (!Files.exists(plan)) {
            return;
        }

        List<String> lines = Files.readAllLines(plan, StandardCharsets.UTF_8);
        if (lines.isEmpty()) {
            errors.add("Plan is empty: " + plan);
            return;
        }

        Map<String, Integer> columns = columns(parseCsv(lines.get(0)));
        for (String required : List.of("ENABLED", "STEP", "COMMAND", "NAME", "TABLE", "PATH", "EXPORT")) {
            if (!columns.containsKey(required)) {
                errors.add("Missing plan column " + required + " in " + plan);
            }
        }

        for (int i = 1; i < lines.size(); i++) {
            String line = lines.get(i);
            if (line.isBlank()) {
                continue;
            }

            List<String> cells = parseCsv(line);
            if (!"TRUE".equalsIgnoreCase(cell(cells, columns, "ENABLED").trim())) {
                continue;
            }

            String command = cell(cells, columns, "COMMAND").trim().toUpperCase(Locale.ROOT);
            Path sqlPath = resolvePlanPath(plan, cell(cells, columns, "PATH").trim());
            Path exportPath = resolvePlanPath(plan, cell(cells, columns, "EXPORT").trim());

            if (("RUN_SQL".equals(command) || "EXPORT_SQL".equals(command)) && sqlPath == null) {
                errors.add("Missing PATH on enabled step line " + (i + 1) + " in " + plan);
            }
            if (sqlPath != null && !Files.exists(sqlPath)) {
                errors.add("Missing SQL path from " + plan.getFileName() + ": " + root.relativize(sqlPath));
            }
            if ("EXPORT_SQL".equals(command) && exportPath == null) {
                errors.add("Missing EXPORT on enabled step line " + (i + 1) + " in " + plan);
            }
            if (exportPath != null && exportPath.getParent() != null && !Files.exists(exportPath.getParent())) {
                errors.add("Missing export directory from " + plan.getFileName() + ": " + root.relativize(exportPath.getParent()));
            }
        }
    }

    private static void require(Path path, List<String> errors) {
        if (!Files.exists(path)) {
            errors.add("Missing required file: " + path);
        }
    }

    private static void checkTextContains(Path path, String text, List<String> errors) throws Exception {
        if (!Files.exists(path)) {
            return;
        }
        String content = Files.readString(path, StandardCharsets.UTF_8);
        if (!content.contains(text)) {
            errors.add(path + " does not contain expected text: " + text);
        }
    }

    private static Map<String, Integer> columns(List<String> header) {
        Map<String, Integer> columns = new LinkedHashMap<>();
        for (int i = 0; i < header.size(); i++) {
            columns.put(stripBom(header.get(i)).trim().toUpperCase(Locale.ROOT), i);
        }
        return columns;
    }

    private static String cell(List<String> row, Map<String, Integer> columns, String name) {
        Integer index = columns.get(name);
        if (index == null || index < 0 || index >= row.size()) {
            return "";
        }
        return row.get(index);
    }

    private static Path resolvePlanPath(Path plan, String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        Path path = Path.of(value.replace("\\", "/"));
        if (path.isAbsolute()) {
            return path.normalize();
        }
        Path parent = plan.toAbsolutePath().getParent();
        return (parent == null ? path : parent.resolve(path)).normalize();
    }

    private static List<String> parseCsv(String line) {
        List<String> cells = new ArrayList<>();
        StringBuilder cell = new StringBuilder();
        boolean quoted = false;
        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (quoted) {
                if (ch == '"') {
                    if (i + 1 < line.length() && line.charAt(i + 1) == '"') {
                        cell.append('"');
                        i++;
                    } else {
                        quoted = false;
                    }
                } else {
                    cell.append(ch);
                }
            } else if (ch == '"') {
                quoted = true;
            } else if (ch == ',') {
                cells.add(cell.toString());
                cell.setLength(0);
            } else {
                cell.append(ch);
            }
        }
        cells.add(cell.toString());
        return cells;
    }

    private static String stripBom(String value) {
        if (value != null && !value.isEmpty() && value.charAt(0) == '\uFEFF') {
            return value.substring(1);
        }
        return value == null ? "" : value;
    }
}

