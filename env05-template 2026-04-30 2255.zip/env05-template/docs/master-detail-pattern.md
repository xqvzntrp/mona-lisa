# Master-Detail UI Pattern

This app uses a small, repeatable Swing pattern inspired by Oracle APEX:

```text
Top-level tab -> master-detail page
Master list   -> searchable read-only table
Detail region -> selected record preview
Child tabs    -> related records/actions
Modal dialogs -> add/edit/assign workflows
Database      -> persistence and relationship integrity
```

## Core Rules

- A `ViewPanel` is one top-level page.
- Each `ViewPanel` owns one master entity and its related child regions.
- Master tables are read-only.
- Double-clicking a master row opens edit when edit is supported.
- Add/Edit actions use modal dialogs.
- Modal dialogs implement `ModalForm<R>` and return either a result or `null`.
- `null` means cancel.
- Child tab buttons affect only that child region.
- Relationship actions connect or disconnect existing records; they do not create unrelated master records.
- SQL constraints enforce relationship integrity.
- Interactive CRUD uses direct JDBC through `Database`.
- Operational/export workflows use SQL runner plans.

## Current Pages

### Notes

`NotesViewPanel` owns the `Note` master-detail page.

```text
Master:
  Notes

Detail:
  selected note preview

Child tabs:
  Links
    Open
    Assign Link
    Remove Link

  Activities
    Add Activity
    Edit
    Delete
```

### Links

`LinksViewPanel` owns the `Link` master-detail page.

```text
Master:
  Links

Detail:
  selected link preview

Child tabs:
  Notes
    Assign to Note
    Remove from Note
```

### Operations

`OperationsViewPanel` owns command-oriented workflows. It is not a master-detail page because
its job is to run app-level operations.

```text
Backup:
  Export CSV Backup

Analysis:
  Run Analysis Export

Output:
  command log and generated file paths
```

Both operations run through the SQL runner plan flow:

```text
backup-plan.csv -> raw SIMPLE_* table backups
run-plan.csv    -> analysis/report exports
```

This keeps UI interactions simple while making exports, backups, reports, and repeatable SQL workflows visible as `.csv` plans and `.sql` files.

## File Roles

```text
NotesFormsApp.java
  App shell. Opens the database, creates top-level tabs, owns the status bar.

ViewPanel.java
  Contract for top-level master-detail pages.

AppContext.java
  Shared app services: owner frame, database, status messages, error dialogs, URL opening.

NotesViewPanel.java
  Notes master-detail page.

LinksViewPanel.java
  Links master-detail page.

OperationsViewPanel.java
  Backup and analysis/export operations.

Database.java
  Direct JDBC persistence for interactive UI operations.

backup-plan.csv, run-plan.csv, sql/*.sql
  SQL runner workflows for backups and analysis exports.

*FormDialog.java
  Add/edit modal dialogs.

Assign*Dialog.java
  Relationship assignment modal dialogs.

*TableModel.java
  Read-only table models.

Note.java, Link.java, Activity.java, AssignedLink.java, LinkNote.java
  Small record types used by views, dialogs, and database methods.
```

## Reusing The Pattern

To add another domain page:

1. Create a record type for the master entity.
2. Add database load/save/delete methods.
3. Create a read-only table model for the master list.
4. Create a `ViewPanel` implementation.
5. Add modal forms for add/edit workflows.
6. Add child tabs for related records.
7. Add the page to `NotesFormsApp`.

The intended rhythm is:

```text
View records -> select one -> inspect details -> use modal dialogs for changes
```
