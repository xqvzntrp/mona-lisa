import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public final class Run {
    private static final List<String> RUNTIME_JARS = List.of(
            "csv-core-1.0-SNAPSHOT.jar",
            "csv-loader-1.0-SNAPSHOT.jar",
            "sql-runner-1.0-SNAPSHOT.jar",
            "ojdbc11-23.3.0.23.09.jar"
    );

    private Run() {
    }

    public static void main(String[] args) throws Exception {
        Path root = Path.of("").toAbsolutePath().normalize();
        validateFiles(root);

        List<String> command = new ArrayList<>();
        command.add(findJava());
        command.add("-cp");
        command.add(classpath(root));
        command.add(root.resolve("PlanRunner.java").toString());
        command.addAll(List.of(args));

        ProcessBuilder builder = new ProcessBuilder(command);
        builder.directory(root.toFile());
        builder.inheritIO();

        Process process = builder.start();
        int exit = process.waitFor();
        if (exit != 0) {
            throw new IllegalStateException("PlanRunner failed with exit code " + exit);
        }
    }

    private static void validateFiles(Path root) {
        requireFile(root.resolve("PlanRunner.java"));
        requireFile(root.resolve("run-plan.csv"));
        requireFile(root.resolve("sql-runner.local.properties"));
        for (String jar : RUNTIME_JARS) {
            requireFile(root.resolve(jar));
        }
    }

    private static void requireFile(Path path) {
        if (!Files.exists(path)) {
            throw new IllegalStateException("Missing required file: " + path);
        }
    }

    private static String classpath(Path root) {
        List<String> paths = new ArrayList<>();
        for (String jar : RUNTIME_JARS) {
            paths.add(root.resolve(jar).toString());
        }
        return String.join(System.getProperty("path.separator"), paths);
    }

    private static String findJava() {
        String javaHome = System.getProperty("java.home");
        if (javaHome == null || javaHome.isBlank()) {
            return "java";
        }

        Path java = Path.of(javaHome, "bin", isWindows() ? "java.exe" : "java");
        return Files.exists(java) ? java.toString() : "java";
    }

    private static boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase().contains("win");
    }
}
