import local.dev.datatools.csv.CsvLineParser;
import local.dev.datatools.csv.CsvParseMode;
import local.dev.datatools.loader.CsvTableLoader;
import local.dev.sql.runner.CsvExporter;
import local.dev.sql.runner.SqlFileRunner;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

public final class PlanRunner {
    private static final String DEFAULT_PROPERTIES = "sql-runner.local.properties";
    private static final String DEFAULT_PLAN = "run-plan.csv";

    private PlanRunner() {
    }

    public static void main(String[] args) throws Exception {
        Options options = Options.parse(args);
        Properties props = loadProperties(options.propertiesPath());
        Path planPath = options.planPath() == null
                ? Path.of(props.getProperty("RUN_PLAN_CSV", DEFAULT_PLAN))
                : options.planPath();

        List<RunStep> steps = RunPlan.read(planPath);

        System.out.println("Unified plan runner");
        System.out.println("Plan: " + planPath.toAbsolutePath());
        System.out.println("Mode: " + (options.dryRun() ? "DRY RUN" : "EXECUTE"));
        System.out.println();

        if (options.dryRun()) {
            printDryRun(steps);
            return;
        }

        String url = requireProperty(props, "SQL_RUNNER_JDBC_URL");
        String user = requireProperty(props, "SQL_RUNNER_JDBC_USER");
        String password = requireProperty(props, "SQL_RUNNER_JDBC_PASSWORD");

        try (Connection connection = DriverManager.getConnection(url, user, password)) {
            connection.setAutoCommit(false);
            boolean dbmsOutputEnabled = enableDbmsOutput(connection);
            try {
                SqlFileRunner sqlFileRunner = new SqlFileRunner(connection);
                CsvExporter exporter = new CsvExporter(connection);

                for (RunStep step : steps) {
                    executeStep(connection, sqlFileRunner, exporter, step, dbmsOutputEnabled);
                }

                connection.commit();
                System.out.println("Plan complete.");
            } catch (Exception e) {
                connection.rollback();
                throw e;
            }
        }
    }

    private static void executeStep(
            Connection connection,
            SqlFileRunner sqlFileRunner,
            CsvExporter exporter,
            RunStep step,
            boolean dbmsOutputEnabled
    ) throws Exception {
        System.out.printf(
                "Step %s: %s - %s%n",
                step.step(),
                step.command(),
                step.name()
        );

        try {
            switch (step.command()) {
                case LOAD_CSV -> CsvTableLoader.load(
                        connection,
                        requireText(step.table(), "TABLE", step),
                        requirePath(step.path(), "PATH", step).toString()
                );
                case RUN_SQL -> sqlFileRunner.executeFile(requirePath(step.path(), "PATH", step));
                case EXPORT_SQL -> {
                    String sql = readExportSql(requirePath(step.path(), "PATH", step));
                    exporter.export(sql, requirePath(step.export(), "EXPORT", step));
                }
            }
        } finally {
            if (dbmsOutputEnabled) {
                printDbmsOutput(connection);
            }
        }
    }

    private static boolean enableDbmsOutput(Connection connection) {
        try (CallableStatement statement = connection.prepareCall("BEGIN DBMS_OUTPUT.ENABLE(NULL); END;")) {
            statement.execute();
            return true;
        } catch (SQLException e) {
            System.out.println("WARNING: DBMS_OUTPUT is unavailable: " + e.getMessage());
            return false;
        }
    }

    private static void printDbmsOutput(Connection connection) {
        try {
            readDbmsOutput(connection);
        } catch (SQLException e) {
            System.out.println("WARNING: Failed to read DBMS_OUTPUT: " + e.getMessage());
        }
    }

    private static void readDbmsOutput(Connection connection) throws SQLException {
        try (CallableStatement statement = connection.prepareCall("BEGIN DBMS_OUTPUT.GET_LINE(?, ?); END;")) {
            statement.registerOutParameter(1, Types.VARCHAR);
            statement.registerOutParameter(2, Types.INTEGER);

            while (true) {
                statement.execute();
                int status = statement.getInt(2);
                if (status != 0) {
                    return;
                }

                String line = statement.getString(1);
                if (line != null) {
                    System.out.println(line);
                }
            }
        }
    }

    private static String readExportSql(Path path) throws IOException {
        String sql = Files.readString(path, StandardCharsets.UTF_8).trim();
        if (sql.endsWith(";")) {
            sql = sql.substring(0, sql.length() - 1).trim();
        }
        if (sql.isBlank()) {
            throw new IllegalArgumentException("Export SQL file is empty: " + path);
        }
        return sql;
    }

    private static void printDryRun(List<RunStep> steps) {
        if (steps.isEmpty()) {
            System.out.println("No enabled steps found.");
            return;
        }

        for (RunStep step : steps) {
            System.out.printf(
                    "%-5s %-10s %-36s table=%-28s path=%-45s export=%s%n",
                    step.step(),
                    step.command(),
                    step.name(),
                    step.table(),
                    step.path(),
                    step.export()
            );
        }
    }

    private static Properties loadProperties(Path path) throws IOException {
        Path resolved = path == null ? Path.of(DEFAULT_PROPERTIES) : path;
        if (!Files.exists(resolved)) {
            throw new IllegalArgumentException("Missing properties file: " + resolved.toAbsolutePath());
        }

        Properties props = new Properties();
        try (InputStream in = Files.newInputStream(resolved)) {
            props.load(in);
            return props;
        }
    }

    private static String requireProperty(Properties props, String name) {
        String value = props.getProperty(name);
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException("Missing required property: " + name);
        }
        return value.trim();
    }

    private static Path requirePath(Path path, String field, RunStep step) {
        if (path == null) {
            throw new IllegalArgumentException("Step " + step.step() + " is missing " + field);
        }
        return path;
    }

    private static String requireText(String value, String field, RunStep step) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException("Step " + step.step() + " is missing " + field);
        }
        return value;
    }

    private enum Command {
        LOAD_CSV,
        RUN_SQL,
        EXPORT_SQL
    }

    private record RunStep(
            boolean enabled,
            int step,
            Command command,
            String name,
            String table,
            Path path,
            Path export
    ) {
    }

    private static final class RunPlan {
        private static final String ENABLED = "ENABLED";
        private static final String STEP = "STEP";
        private static final String COMMAND = "COMMAND";
        private static final String NAME = "NAME";
        private static final String TABLE = "TABLE";
        private static final String PATH = "PATH";
        private static final String EXPORT = "EXPORT";

        private RunPlan() {
        }

        private static List<RunStep> read(Path planPath) throws IOException {
            List<String> lines = Files.readAllLines(planPath, StandardCharsets.UTF_8);
            if (lines.isEmpty()) {
                throw new IllegalArgumentException("Plan is empty: " + planPath);
            }

            List<String> header = CsvLineParser.parse(lines.get(0), ',', CsvParseMode.STRICT, null).fields();
            Map<String, Integer> columns = resolveColumns(header, planPath);
            List<RunStep> steps = new ArrayList<>();

            for (int i = 1; i < lines.size(); i++) {
                String line = lines.get(i);
                if (line.isBlank()) {
                    continue;
                }

                List<String> cells = CsvLineParser.parse(line, ',', CsvParseMode.STRICT, null).fields();
                if (!booleanValue(cell(cells, columns, ENABLED))) {
                    continue;
                }

                int step = integerValue(cell(cells, columns, STEP), i + 1);
                Command command = Command.valueOf(cell(cells, columns, COMMAND).trim().toUpperCase(Locale.ROOT));
                String name = defaultText(cell(cells, columns, NAME), command.name());
                String table = cell(cells, columns, TABLE).trim();
                Path path = resolveRelative(planPath, cell(cells, columns, PATH).trim());
                Path export = resolveRelative(planPath, cell(cells, columns, EXPORT).trim());

                steps.add(new RunStep(true, step, command, name, table, path, export));
            }

            steps.sort(Comparator.comparingInt(RunStep::step));
            validateSteps(steps);
            return steps;
        }

        private static Map<String, Integer> resolveColumns(List<String> header, Path planPath) {
            Map<String, Integer> columns = new HashMap<>();
            for (int i = 0; i < header.size(); i++) {
                String name = stripBom(header.get(i)).trim();
                if (!name.isEmpty()) {
                    columns.put(name.toUpperCase(Locale.ROOT), i);
                }
            }

            for (String required : List.of(ENABLED, STEP, COMMAND, NAME, TABLE, PATH, EXPORT)) {
                if (!columns.containsKey(required)) {
                    throw new IllegalArgumentException("Missing required column " + required + " in " + planPath);
                }
            }
            return columns;
        }

        private static void validateSteps(List<RunStep> steps) {
            for (RunStep step : steps) {
                switch (step.command()) {
                    case LOAD_CSV -> {
                        requireText(step.table(), TABLE, step);
                        requirePath(step.path(), PATH, step);
                    }
                    case RUN_SQL -> requirePath(step.path(), PATH, step);
                    case EXPORT_SQL -> {
                        requirePath(step.path(), PATH, step);
                        requirePath(step.export(), EXPORT, step);
                    }
                }
            }
        }

        private static String cell(List<String> cells, Map<String, Integer> columns, String name) {
            Integer index = columns.get(name);
            if (index == null || index < 0 || index >= cells.size()) {
                return "";
            }
            return cells.get(index);
        }

        private static boolean booleanValue(String value) {
            return "TRUE".equalsIgnoreCase(value == null ? "" : value.trim());
        }

        private static int integerValue(String value, int lineNumber) {
            try {
                return Integer.parseInt(value.trim());
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("Invalid STEP on plan line " + lineNumber + ": " + value, e);
            }
        }

        private static String defaultText(String value, String fallback) {
            return value == null || value.isBlank() ? fallback : value.trim();
        }

        private static Path resolveRelative(Path planPath, String value) {
            if (value == null || value.isBlank()) {
                return null;
            }
            Path path = Path.of(value.replace("\\", "/"));
            if (path.isAbsolute()) {
                return path;
            }
            Path parent = planPath.toAbsolutePath().getParent();
            return parent == null ? path : parent.resolve(path).normalize();
        }

        private static String stripBom(String value) {
            if (value != null && !value.isEmpty() && value.charAt(0) == '\uFEFF') {
                return value.substring(1);
            }
            return value == null ? "" : value;
        }
    }

    private record Options(Path propertiesPath, Path planPath, boolean dryRun) {
        private static Options parse(String[] args) {
            Path propertiesPath = null;
            Path planPath = null;
            boolean dryRun = false;

            for (int i = 0; i < args.length; i++) {
                String arg = args[i];
                switch (arg) {
                    case "--properties" -> propertiesPath = Path.of(requireArg(args, ++i, arg));
                    case "--plan" -> planPath = Path.of(requireArg(args, ++i, arg));
                    case "--dry-run" -> dryRun = true;
                    default -> throw new IllegalArgumentException("Unknown argument: " + arg);
                }
            }

            return new Options(propertiesPath, planPath, dryRun);
        }

        private static String requireArg(String[] args, int index, String option) {
            if (index >= args.length || args[index].startsWith("--")) {
                throw new IllegalArgumentException("Missing value for " + option);
            }
            return args[index];
        }
    }
}
