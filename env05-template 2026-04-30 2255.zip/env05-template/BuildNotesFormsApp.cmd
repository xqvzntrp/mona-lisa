﻿@echo off
setlocal
cd /d "%~dp0"
mvn clean install
if errorlevel 1 pause & exit /b %errorlevel%
echo.
echo Build complete.
pause

