--#BEGIN
BEGIN
    -- TABLES
    FOR t IN (SELECT table_name FROM user_tables) LOOP
        BEGIN
            EXECUTE IMMEDIATE 'DROP TABLE ' || t.table_name || ' CASCADE CONSTRAINTS PURGE';
        EXCEPTION WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('FAILED TABLE: ' || t.table_name || ' - ' || SQLERRM);
        END;
    END LOOP;

    -- VIEWS
    FOR v IN (SELECT view_name FROM user_views) LOOP
        BEGIN
            EXECUTE IMMEDIATE 'DROP VIEW ' || v.view_name;
        EXCEPTION WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('FAILED VIEW: ' || v.view_name || ' - ' || SQLERRM);
        END;
    END LOOP;

    -- PACKAGES
    FOR p IN (SELECT object_name FROM user_objects WHERE object_type = 'PACKAGE') LOOP
        BEGIN
            EXECUTE IMMEDIATE 'DROP PACKAGE ' || p.object_name;
        EXCEPTION WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('FAILED PACKAGE: ' || p.object_name || ' - ' || SQLERRM);
        END;
    END LOOP;

    -- FUNCTIONS
    FOR f IN (SELECT object_name FROM user_objects WHERE object_type = 'FUNCTION') LOOP
        BEGIN
            EXECUTE IMMEDIATE 'DROP FUNCTION ' || f.object_name;
        EXCEPTION WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('FAILED FUNCTION: ' || f.object_name || ' - ' || SQLERRM);
        END;
    END LOOP;

    -- PROCEDURES
    FOR pr IN (SELECT object_name FROM user_objects WHERE object_type = 'PROCEDURE') LOOP
        BEGIN
            EXECUTE IMMEDIATE 'DROP PROCEDURE ' || pr.object_name;
        EXCEPTION WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('FAILED PROCEDURE: ' || pr.object_name || ' - ' || SQLERRM);
        END;
    END LOOP;

    -- TRIGGERS
    FOR tr IN (SELECT trigger_name FROM user_triggers) LOOP
        BEGIN
            EXECUTE IMMEDIATE 'DROP TRIGGER ' || tr.trigger_name;
        EXCEPTION WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('FAILED TRIGGER: ' || tr.trigger_name || ' - ' || SQLERRM);
        END;
    END LOOP;

    -- TYPES
    FOR ty IN (SELECT type_name FROM user_types) LOOP
        BEGIN
            EXECUTE IMMEDIATE 'DROP TYPE ' || ty.type_name || ' FORCE';
        EXCEPTION WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('FAILED TYPE: ' || ty.type_name || ' - ' || SQLERRM);
        END;
    END LOOP;

    -- SEQUENCES
    FOR s IN (SELECT sequence_name FROM user_sequences) LOOP
        BEGIN
            EXECUTE IMMEDIATE 'DROP SEQUENCE ' || s.sequence_name;
        EXCEPTION WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('FAILED SEQUENCE: ' || s.sequence_name || ' - ' || SQLERRM);
        END;
    END LOOP;

END;
--#END