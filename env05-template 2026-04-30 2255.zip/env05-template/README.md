# env05-template

Reusable plain-Java Swing template for Oracle-backed master-detail apps.

## What This Template Provides

```text
src/main/java/
  Maven app source

NotesFormsApp.java
  App shell with top-level tabs

ViewPanel.java
  Contract for master-detail pages

NotesViewPanel.java / LinksViewPanel.java
  Example master-detail pages

OperationsViewPanel.java
  SQL-runner operations: backup and analysis export

Database.java
  Direct JDBC persistence for interactive CRUD

docs/master-detail-pattern.md
  Reusable UI and workflow pattern
```

## Build

```bat
BuildNotesFormsApp.cmd
```

or:

```bat
mvn clean install
```

This creates:

```text
target/env05-template-1.0-SNAPSHOT.jar
```

## Run

```bat
RunNotesFormsApp.cmd
```

or:

```bat
java -jar target\env05-template-1.0-SNAPSHOT.jar
```

## Configure Local Database

Copy:

```text
sql-runner.local.properties.example
```

to:

```text
sql-runner.local.properties
```

Then set your local Oracle JDBC URL, user, and password.

`sql-runner.local.properties` is ignored by git.

## Wiring Check

```bat
CheckProjectWiring.cmd
```

This verifies that key files exist, plan files reference existing SQL/export directories, and scripts point at the expected jar.

## SQL Runner Plans

```text
backup-plan.csv -> raw SIMPLE_* table backups
run-plan.csv    -> analysis/report exports
```

## Starting A New Project

Recommended first changes:

1. Rename the Maven artifact in `pom.xml`.
2. Rename scripts if desired.
3. Replace example domain records and panels with your domain.
4. Update `sql/simple-notes-schema.sql` and plan SQL files.
5. Run `CheckProjectWiring.cmd`.
6. Run `BuildNotesFormsApp.cmd`.

## Design Rule

Use direct JDBC for interactive CRUD. Use SQL runner plans for operational, backup, report, and repeatable SQL workflows.
