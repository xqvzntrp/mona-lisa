record Activity(
        String id,
        String noteId,
        String activityType,
        String activityText,
        String createdAt,
        String updatedAt
) {
}
