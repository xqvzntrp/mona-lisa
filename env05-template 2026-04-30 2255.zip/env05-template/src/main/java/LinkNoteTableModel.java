import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;

final class LinkNoteTableModel extends AbstractTableModel {
    private static final List<String> COLUMNS = List.of("Note", "Updated", "Assigned");
    private final List<LinkNote> rows = new ArrayList<>();

    void setRows(List<LinkNote> loaded) {
        rows.clear();
        rows.addAll(loaded);
        fireTableDataChanged();
    }

    LinkNote rowAt(int row) {
        return rows.get(row);
    }

    @Override
    public int getRowCount() {
        return rows.size();
    }

    @Override
    public int getColumnCount() {
        return COLUMNS.size();
    }

    @Override
    public String getColumnName(int column) {
        return COLUMNS.get(column);
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        LinkNote row = rows.get(rowIndex);
        return switch (columnIndex) {
            case 0 -> row.title();
            case 1 -> row.updatedAt();
            case 2 -> row.assignedAt();
            default -> "";
        };
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return false;
    }
}
