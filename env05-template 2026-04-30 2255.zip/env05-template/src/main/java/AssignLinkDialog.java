import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.RowFilter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.TableRowSorter;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Window;
import java.util.List;

final class AssignLinkDialog extends JDialog implements ModalForm<AssignLinkDialog.Result> {
    private final LinkTableModel model = new LinkTableModel();
    private final JTable table = new JTable(model);
    private final TableRowSorter<LinkTableModel> sorter = new TableRowSorter<>(model);
    private final JTextField searchField = new JTextField();
    private Result result;

    AssignLinkDialog(Window owner, List<Link> links) {
        super(owner, "Assign Link", ModalityType.APPLICATION_MODAL);
        setLayout(new BorderLayout(8, 8));

        model.setLinks(links);
        table.setRowSorter(sorter);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setFillsViewportHeight(true);
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent event) {
                if (event.getClickCount() == 2 && table.getSelectedRow() >= 0) {
                    assign();
                }
            }
        });

        searchField.putClientProperty("JTextField.placeholderText", "Search links");
        searchField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent event) {
                updateFilter();
            }

            @Override
            public void removeUpdate(DocumentEvent event) {
                updateFilter();
            }

            @Override
            public void changedUpdate(DocumentEvent event) {
                updateFilter();
            }
        });

        JPanel content = new JPanel(new BorderLayout(0, 8));
        content.setBorder(BorderFactory.createEmptyBorder(10, 10, 0, 10));
        content.add(searchField, BorderLayout.NORTH);
        content.add(new JScrollPane(table), BorderLayout.CENTER);

        add(content, BorderLayout.CENTER);
        add(buttons(), BorderLayout.SOUTH);
        pack();
        setMinimumSize(new Dimension(620, 420));
        setLocationRelativeTo(owner);
    }

    private JPanel buttons() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton assignButton = new JButton("Assign");
        JButton cancelButton = new JButton("Cancel");

        assignButton.addActionListener(event -> assign());
        cancelButton.addActionListener(event -> dispose());
        getRootPane().setDefaultButton(assignButton);

        panel.add(cancelButton);
        panel.add(assignButton);
        return panel;
    }

    private void updateFilter() {
        String text = searchField.getText().trim();
        if (text.isEmpty()) {
            sorter.setRowFilter(null);
        } else {
            sorter.setRowFilter(RowFilter.regexFilter("(?i)" + java.util.regex.Pattern.quote(text)));
        }
    }

    @Override
    public Result showDialog() {
        setVisible(true);
        return result;
    }

    private void assign() {
        int viewRow = table.getSelectedRow();
        if (viewRow < 0) {
            JOptionPane.showMessageDialog(this, "Select a link.", "No link selected", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Link link = model.linkAt(table.convertRowIndexToModel(viewRow));
        result = new Result(link.id());
        dispose();
    }

    record Result(String linkId) {
    }
}
