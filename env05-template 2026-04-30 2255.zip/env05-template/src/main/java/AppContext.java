import javax.swing.JFrame;
import javax.swing.JOptionPane;
import java.awt.Desktop;
import java.net.URI;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

final class AppContext {
    private final JFrame owner;
    private final Database database;
    private final Consumer<String> status;
    private final BiConsumer<String, Exception> error;

    AppContext(JFrame owner, Database database, Consumer<String> status, BiConsumer<String, Exception> error) {
        this.owner = owner;
        this.database = database;
        this.status = status;
        this.error = error;
    }

    JFrame owner() {
        return owner;
    }

    Database database() {
        return database;
    }

    void status(String message) {
        status.accept(message);
    }

    void error(String title, Exception e) {
        error.accept(title, e);
    }

    void openUrl(String url, String title) {
        try {
            if (url.isBlank()) {
                throw new IllegalArgumentException("Selected link has no URL.");
            }
            if (!Desktop.isDesktopSupported() || !Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
                throw new IllegalStateException("Opening links is not supported on this desktop.");
            }
            Desktop.getDesktop().browse(new URI(url));
            status("Opened " + title + ".");
        } catch (Exception e) {
            error("Open link failed", e);
        }
    }

    static void showStartupError(Exception e) {
        JOptionPane.showMessageDialog(null, e.getMessage(), "Startup failed", JOptionPane.ERROR_MESSAGE);
    }
}
