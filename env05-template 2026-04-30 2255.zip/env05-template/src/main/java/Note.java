record Note(String id, String title, String body, String createdAt, String updatedAt) {
}
