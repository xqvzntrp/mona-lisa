interface ModalForm<R> {
    R showDialog();
}
