record AssignedLink(String linkId, String title, String url, String assignedAt) {
}
