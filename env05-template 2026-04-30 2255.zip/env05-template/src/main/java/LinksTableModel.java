import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;

final class LinksTableModel extends AbstractTableModel {
    private static final List<String> COLUMNS = List.of("Title", "URL", "Assigned");
    private final List<AssignedLink> links = new ArrayList<>();

    void setLinks(List<AssignedLink> loaded) {
        links.clear();
        links.addAll(loaded);
        fireTableDataChanged();
    }

    AssignedLink linkAt(int row) {
        return links.get(row);
    }

    @Override
    public int getRowCount() {
        return links.size();
    }

    @Override
    public int getColumnCount() {
        return COLUMNS.size();
    }

    @Override
    public String getColumnName(int column) {
        return COLUMNS.get(column);
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        AssignedLink link = links.get(rowIndex);
        return switch (columnIndex) {
            case 0 -> link.title();
            case 1 -> link.url();
            case 2 -> link.assignedAt();
            default -> "";
        };
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return false;
    }
}
