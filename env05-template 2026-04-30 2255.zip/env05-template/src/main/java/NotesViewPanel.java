import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.RowFilter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.TableRowSorter;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

final class NotesViewPanel extends JPanel implements ViewPanel {
    private final AppContext context;
    private final NotesTableModel notesModel = new NotesTableModel();
    private final LinksTableModel linksModel = new LinksTableModel();
    private final ActivitiesTableModel activitiesModel = new ActivitiesTableModel();
    private final JTable notesTable = new JTable(notesModel);
    private final JTable linksTable = new JTable(linksModel);
    private final JTable activitiesTable = new JTable(activitiesModel);
    private final TableRowSorter<NotesTableModel> notesSorter = new TableRowSorter<>(notesModel);
    private final JTextField searchField = new JTextField();
    private final JTextArea detailText = new JTextArea();

    NotesViewPanel(AppContext context) {
        super(new BorderLayout());
        this.context = context;

        notesTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        notesTable.setAutoCreateRowSorter(false);
        notesTable.setRowSorter(notesSorter);
        notesTable.setFillsViewportHeight(true);
        notesTable.getSelectionModel().addListSelectionListener(event -> {
            if (!event.getValueIsAdjusting()) {
                showSelectedNote();
            }
        });
        notesTable.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent event) {
                if (event.getClickCount() == 2 && notesTable.getSelectedRow() >= 0) {
                    editSelectedNote();
                }
            }
        });

        detailText.setEditable(false);
        detailText.setLineWrap(true);
        detailText.setWrapStyleWord(true);
        detailText.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        linksTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        linksTable.setFillsViewportHeight(true);
        linksTable.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent event) {
                if (event.getClickCount() == 2 && linksTable.getSelectedRow() >= 0) {
                    openSelectedLink();
                }
            }
        });

        activitiesTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        activitiesTable.setFillsViewportHeight(true);
        activitiesTable.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent event) {
                if (event.getClickCount() == 2 && activitiesTable.getSelectedRow() >= 0) {
                    editSelectedActivity();
                }
            }
        });

        add(actionBar(), BorderLayout.NORTH);
        add(content(), BorderLayout.CENTER);

        installSearchFilter();
        refreshNotes(null);
    }

    @Override
    public String title() {
        return "Notes";
    }

    @Override
    public JPanel panel() {
        return this;
    }

    @Override
    public void refresh() {
        refreshNotes(selectedNoteId());
    }

    void refreshSelectedDetails() {
        showSelectedNote();
    }

    private JPanel actionBar() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        JLabel title = new JLabel("Notes");
        title.setFont(title.getFont().deriveFont(20f));

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        JButton refreshButton = new JButton("Refresh");
        JButton newButton = new JButton("Add Note");
        JButton editButton = new JButton("Edit");
        JButton deleteButton = new JButton("Delete");

        refreshButton.addActionListener(event -> refreshNotes(selectedNoteId()));
        newButton.addActionListener(event -> addNote());
        editButton.addActionListener(event -> editSelectedNote());
        deleteButton.addActionListener(event -> deleteSelectedNote());

        buttons.add(refreshButton);
        buttons.add(newButton);
        buttons.add(editButton);
        buttons.add(deleteButton);

        panel.add(title, BorderLayout.WEST);
        panel.add(buttons, BorderLayout.EAST);
        return panel;
    }

    private JSplitPane content() {
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, masterPanel(), detailPanel());
        split.setResizeWeight(0.34);
        split.setDividerLocation(340);
        return split;
    }

    private JPanel masterPanel() {
        JPanel panel = new JPanel(new BorderLayout(0, 8));
        panel.setBorder(BorderFactory.createEmptyBorder(0, 8, 8, 4));

        searchField.putClientProperty("JTextField.placeholderText", "Search notes");
        panel.add(searchField, BorderLayout.NORTH);
        panel.add(new JScrollPane(notesTable), BorderLayout.CENTER);
        return panel;
    }

    private JPanel detailPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(0, 4, 8, 8));

        JTabbedPane detailTabs = new JTabbedPane();
        detailTabs.addTab("Links", linksPanel());
        detailTabs.addTab("Activities", activitiesPanel());

        JSplitPane split = new JSplitPane(
                JSplitPane.VERTICAL_SPLIT,
                new JScrollPane(detailText),
                detailTabs
        );
        split.setResizeWeight(0.58);
        split.setDividerLocation(290);

        panel.add(split, BorderLayout.CENTER);
        return panel;
    }

    private static JPanel tablePanel(JTable table) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        return panel;
    }

    private JPanel linksPanel() {
        JPanel panel = tablePanel(linksTable);
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 4));
        JButton openButton = new JButton("Open");
        JButton assignButton = new JButton("Assign Link");
        JButton removeButton = new JButton("Remove Link");
        openButton.addActionListener(event -> openSelectedLink());
        assignButton.addActionListener(event -> assignLink());
        removeButton.addActionListener(event -> removeSelectedLink());
        buttons.add(openButton);
        buttons.add(assignButton);
        buttons.add(removeButton);
        panel.add(buttons, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel activitiesPanel() {
        JPanel panel = tablePanel(activitiesTable);
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 4));
        JButton addButton = new JButton("Add Activity");
        JButton editButton = new JButton("Edit");
        JButton deleteButton = new JButton("Delete");
        addButton.addActionListener(event -> addActivity());
        editButton.addActionListener(event -> editSelectedActivity());
        deleteButton.addActionListener(event -> deleteSelectedActivity());
        buttons.add(addButton);
        buttons.add(editButton);
        buttons.add(deleteButton);
        panel.add(buttons, BorderLayout.SOUTH);
        return panel;
    }

    private void installSearchFilter() {
        searchField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent event) {
                updateFilter();
            }

            @Override
            public void removeUpdate(DocumentEvent event) {
                updateFilter();
            }

            @Override
            public void changedUpdate(DocumentEvent event) {
                updateFilter();
            }
        });
    }

    private void updateFilter() {
        String text = searchField.getText().trim();
        if (text.isEmpty()) {
            notesSorter.setRowFilter(null);
        } else {
            notesSorter.setRowFilter(RowFilter.regexFilter("(?i)" + java.util.regex.Pattern.quote(text)));
        }
        showSelectedNote();
    }

    private void refreshNotes(String selectId) {
        try {
            notesModel.setNotes(context.database().loadNotes());
            if (selectId != null) {
                selectNote(selectId);
            }
            if (notesTable.getSelectedRow() < 0 && notesTable.getRowCount() > 0) {
                notesTable.setRowSelectionInterval(0, 0);
            }
            showSelectedNote();
            context.status("Loaded " + notesModel.getRowCount() + " note(s).");
        } catch (Exception e) {
            context.error("Refresh failed", e);
        }
    }

    private void addNote() {
        NoteFormDialog dialog = new NoteFormDialog(context.owner(), null);
        NoteFormDialog.Result result = dialog.showDialog();
        if (result == null) {
            return;
        }

        try {
            String now = AppClock.now();
            Note note = new Note(UUID.randomUUID().toString(), result.title(), result.body(), now, now);
            context.database().upsertNote(note);
            refreshNotes(note.id());
            context.status("Added note.");
        } catch (Exception e) {
            context.error("Add note failed", e);
        }
    }

    private void editSelectedNote() {
        Note note = selectedNote();
        if (note == null) {
            return;
        }

        NoteFormDialog dialog = new NoteFormDialog(context.owner(), note);
        NoteFormDialog.Result result = dialog.showDialog();
        if (result == null) {
            return;
        }

        try {
            Note updated = new Note(note.id(), result.title(), result.body(), note.createdAt(), AppClock.now());
            context.database().upsertNote(updated);
            refreshNotes(updated.id());
            context.status("Saved note.");
        } catch (Exception e) {
            context.error("Edit note failed", e);
        }
    }

    private void deleteSelectedNote() {
        Note note = selectedNote();
        if (note == null) {
            return;
        }

        int choice = JOptionPane.showConfirmDialog(
                context.owner(),
                "Delete note \"" + AppText.displayTitle(note) + "\"?",
                "Delete note",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.WARNING_MESSAGE
        );
        if (choice != JOptionPane.OK_OPTION) {
            return;
        }

        try {
            context.database().deleteNote(note.id());
            refreshNotes(null);
            context.status("Deleted note.");
        } catch (SQLException e) {
            if (isReferencedParent(e)) {
                context.error(
                        "Delete note blocked",
                        new IllegalStateException("Remove linked resources and activities before deleting this note.")
                );
            } else {
                context.error("Delete note failed", e);
            }
        } catch (Exception e) {
            context.error("Delete note failed", e);
        }
    }

    private void showSelectedNote() {
        Note note = selectedNote();
        if (note == null) {
            detailText.setText("Select a note to view details.");
            linksModel.setLinks(List.of());
            activitiesModel.setActivities(List.of());
            return;
        }

        detailText.setText("""
                Title: %s
                Updated: %s
                Created: %s

                %s
                """.formatted(AppText.displayTitle(note), note.updatedAt(), note.createdAt(), note.body()));
        detailText.setCaretPosition(0);
        loadLinksFor(note);
        loadActivitiesFor(note);
    }

    private void loadLinksFor(Note note) {
        try {
            linksModel.setLinks(context.database().loadAssignedLinks(note.id()));
        } catch (Exception e) {
            linksModel.setLinks(List.of());
            context.error("Load linked resources failed", e);
        }
    }

    private void loadActivitiesFor(Note note) {
        try {
            activitiesModel.setActivities(context.database().loadActivities(note.id()));
        } catch (Exception e) {
            activitiesModel.setActivities(List.of());
            context.error("Load activities failed", e);
        }
    }

    private void addActivity() {
        Note note = selectedNote();
        if (note == null) {
            return;
        }

        ActivityFormDialog dialog = new ActivityFormDialog(context.owner(), null);
        ActivityFormDialog.Result result = dialog.showDialog();
        if (result == null) {
            return;
        }

        try {
            String now = AppClock.now();
            Activity activity = new Activity(
                    UUID.randomUUID().toString(),
                    note.id(),
                    result.activityType(),
                    result.activityText(),
                    now,
                    now
            );
            context.database().upsertActivity(activity);
            loadActivitiesFor(note);
            context.status("Added activity.");
        } catch (Exception e) {
            context.error("Add activity failed", e);
        }
    }

    private void editSelectedActivity() {
        Note note = selectedNote();
        Activity activity = selectedActivity();
        if (note == null || activity == null) {
            return;
        }

        ActivityFormDialog dialog = new ActivityFormDialog(context.owner(), activity);
        ActivityFormDialog.Result result = dialog.showDialog();
        if (result == null) {
            return;
        }

        try {
            Activity updated = new Activity(
                    activity.id(),
                    activity.noteId(),
                    result.activityType(),
                    result.activityText(),
                    activity.createdAt(),
                    AppClock.now()
            );
            context.database().upsertActivity(updated);
            loadActivitiesFor(note);
            context.status("Saved activity.");
        } catch (Exception e) {
            context.error("Edit activity failed", e);
        }
    }

    private void deleteSelectedActivity() {
        Note note = selectedNote();
        Activity activity = selectedActivity();
        if (note == null || activity == null) {
            return;
        }

        int choice = JOptionPane.showConfirmDialog(
                context.owner(),
                "Delete selected activity?",
                "Delete activity",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.WARNING_MESSAGE
        );
        if (choice != JOptionPane.OK_OPTION) {
            return;
        }

        try {
            context.database().deleteActivity(activity.id());
            loadActivitiesFor(note);
            context.status("Deleted activity.");
        } catch (Exception e) {
            context.error("Delete activity failed", e);
        }
    }

    private void openSelectedLink() {
        AssignedLink link = selectedLink();
        if (link == null) {
            return;
        }

        context.openUrl(link.url(), link.title());
    }

    private AssignedLink selectedLink() {
        int viewRow = linksTable.getSelectedRow();
        if (viewRow < 0) {
            return null;
        }
        return linksModel.linkAt(linksTable.convertRowIndexToModel(viewRow));
    }

    private void assignLink() {
        Note note = selectedNote();
        if (note == null) {
            return;
        }

        try {
            AssignLinkDialog dialog = new AssignLinkDialog(context.owner(), context.database().loadLinks());
            AssignLinkDialog.Result result = dialog.showDialog();
            if (result == null) {
                return;
            }

            context.database().assignNoteLink(note.id(), result.linkId(), AppClock.now());
            loadLinksFor(note);
            context.status("Assigned link.");
        } catch (Exception e) {
            context.error("Assign link failed", e);
        }
    }

    private void removeSelectedLink() {
        Note note = selectedNote();
        AssignedLink link = selectedLink();
        if (note == null || link == null) {
            return;
        }

        int choice = JOptionPane.showConfirmDialog(
                context.owner(),
                "Remove link \"" + AppText.displayTitle(link) + "\" from this note?",
                "Remove link",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.WARNING_MESSAGE
        );
        if (choice != JOptionPane.OK_OPTION) {
            return;
        }

        try {
            context.database().removeNoteLink(note.id(), link.linkId());
            loadLinksFor(note);
            context.status("Removed link.");
        } catch (Exception e) {
            context.error("Remove link failed", e);
        }
    }

    private Activity selectedActivity() {
        int viewRow = activitiesTable.getSelectedRow();
        if (viewRow < 0) {
            return null;
        }
        return activitiesModel.activityAt(activitiesTable.convertRowIndexToModel(viewRow));
    }

    private Note selectedNote() {
        int viewRow = notesTable.getSelectedRow();
        if (viewRow < 0) {
            return null;
        }
        return notesModel.noteAt(notesTable.convertRowIndexToModel(viewRow));
    }

    private String selectedNoteId() {
        Note note = selectedNote();
        return note == null ? null : note.id();
    }

    private void selectNote(String id) {
        for (int modelRow = 0; modelRow < notesModel.getRowCount(); modelRow++) {
            if (notesModel.noteAt(modelRow).id().equals(id)) {
                int viewRow = notesTable.convertRowIndexToView(modelRow);
                if (viewRow >= 0) {
                    notesTable.setRowSelectionInterval(viewRow, viewRow);
                }
                return;
            }
        }
    }

    private static boolean isReferencedParent(SQLException e) {
        for (SQLException current = e; current != null; current = current.getNextException()) {
            if (current.getErrorCode() == 2292) {
                return true;
            }
        }
        return false;
    }
}
