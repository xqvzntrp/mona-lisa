import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

final class AppClock {
    private static final DateTimeFormatter TIMESTAMP = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private AppClock() {
    }

    static String now() {
        return LocalDateTime.now().format(TIMESTAMP);
    }
}
