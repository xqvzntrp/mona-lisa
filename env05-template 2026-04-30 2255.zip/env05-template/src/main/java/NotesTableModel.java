import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;

final class NotesTableModel extends AbstractTableModel {
    private static final List<String> COLUMNS = List.of("Title", "Updated");
    private final List<Note> notes = new ArrayList<>();

    void setNotes(List<Note> loaded) {
        notes.clear();
        notes.addAll(loaded);
        fireTableDataChanged();
    }

    Note noteAt(int row) {
        return notes.get(row);
    }

    @Override
    public int getRowCount() {
        return notes.size();
    }

    @Override
    public int getColumnCount() {
        return COLUMNS.size();
    }

    @Override
    public String getColumnName(int column) {
        return COLUMNS.get(column);
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Note note = notes.get(rowIndex);
        return switch (columnIndex) {
            case 0 -> AppText.displayTitle(note);
            case 1 -> note.updatedAt();
            default -> "";
        };
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return false;
    }
}
