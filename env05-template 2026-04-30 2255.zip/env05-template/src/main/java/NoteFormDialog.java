import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Window;

final class NoteFormDialog extends JDialog implements ModalForm<NoteFormDialog.Result> {
    private final JTextField titleField = new JTextField(36);
    private final JTextArea bodyArea = new JTextArea(12, 42);
    private Result result;

    NoteFormDialog(Window owner, Note note) {
        super(owner, note == null ? "Add Note" : "Edit Note", ModalityType.APPLICATION_MODAL);
        setLayout(new BorderLayout(8, 8));

        bodyArea.setLineWrap(true);
        bodyArea.setWrapStyleWord(true);
        if (note != null) {
            titleField.setText(note.title());
            bodyArea.setText(note.body());
        }

        add(fields(), BorderLayout.CENTER);
        add(buttons(), BorderLayout.SOUTH);
        pack();
        setMinimumSize(new Dimension(520, 360));
        setLocationRelativeTo(owner);
    }

    private JPanel fields() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 0, 10));

        GridBagConstraints constraints = new GridBagConstraints();
        constraints.insets = new Insets(0, 0, 8, 0);
        constraints.anchor = GridBagConstraints.WEST;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 0;
        constraints.gridy = 0;
        panel.add(new JLabel("Title"), constraints);

        constraints.gridy = 1;
        constraints.weightx = 1;
        panel.add(titleField, constraints);

        constraints.gridy = 2;
        constraints.weightx = 0;
        panel.add(new JLabel("Body"), constraints);

        constraints.gridy = 3;
        constraints.weightx = 1;
        constraints.weighty = 1;
        constraints.fill = GridBagConstraints.BOTH;
        panel.add(new JScrollPane(bodyArea), constraints);
        return panel;
    }

    private JPanel buttons() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton saveButton = new JButton("Save");
        JButton cancelButton = new JButton("Cancel");

        saveButton.addActionListener(event -> save());
        cancelButton.addActionListener(event -> dispose());
        getRootPane().setDefaultButton(saveButton);

        panel.add(cancelButton);
        panel.add(saveButton);
        return panel;
    }

    @Override
    public Result showDialog() {
        setVisible(true);
        return result;
    }

    private void save() {
        String title = titleField.getText().trim();
        String body = bodyArea.getText().trim();
        if (title.isBlank() && body.isBlank()) {
            JOptionPane.showMessageDialog(this, "Enter a title or body.", "Note is empty", JOptionPane.WARNING_MESSAGE);
            return;
        }

        result = new Result(title, body);
        dispose();
    }

    record Result(String title, String body) {
    }
}
