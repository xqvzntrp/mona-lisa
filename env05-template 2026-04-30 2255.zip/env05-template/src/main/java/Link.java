record Link(String id, String title, String url) {
}
