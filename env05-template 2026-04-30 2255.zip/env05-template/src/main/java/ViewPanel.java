import javax.swing.JPanel;

interface ViewPanel {
    String title();

    JPanel panel();

    void refresh();
}
