import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import javax.swing.SwingWorker;

final class OperationsViewPanel extends JPanel implements ViewPanel {
    private final AppContext context;
    private final JTextArea output = new JTextArea();
    private final JButton backupButton = new JButton("Export CSV Backup");
    private final JButton analysisButton = new JButton("Run Analysis Export");

    OperationsViewPanel(AppContext context) {
        super(new BorderLayout());
        this.context = context;

        output.setEditable(false);
        output.setLineWrap(true);
        output.setWrapStyleWord(true);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttons.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        buttons.add(backupButton);
        buttons.add(analysisButton);

        backupButton.addActionListener(event -> backupCsv());
        analysisButton.addActionListener(event -> runAnalysisExport());

        add(buttons, BorderLayout.NORTH);
        add(new JScrollPane(output), BorderLayout.CENTER);
    }

    @Override
    public String title() {
        return "Operations";
    }

    @Override
    public JPanel panel() {
        return this;
    }

    @Override
    public void refresh() {
        append("Operations ready.");
    }

    private void backupCsv() {
        runPlan("backup-plan.csv", "CSV backup");
    }

    private void runAnalysisExport() {
        runPlan("run-plan.csv", "Analysis export");
    }

    private void runPlan(String planPath, String label) {
        setButtonsEnabled(false);
        output.setText("");
        append("Running java Run.java --plan " + planPath + "...");

        new SwingWorker<Integer, String>() {
            @Override
            protected Integer doInBackground() throws Exception {
                List<String> command = new ArrayList<>();
                command.add(findJava());
                command.add("Run.java");
                command.add("--plan");
                command.add(planPath);

                ProcessBuilder builder = new ProcessBuilder(command);
                builder.directory(Path.of("").toAbsolutePath().normalize().toFile());
                builder.redirectErrorStream(true);

                Process process = builder.start();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                        process.getInputStream(),
                        StandardCharsets.UTF_8
                ))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        publish(line);
                    }
                }
                return process.waitFor();
            }

            @Override
            protected void process(List<String> chunks) {
                chunks.forEach(OperationsViewPanel.this::append);
            }

            @Override
            protected void done() {
                try {
                    int exit = get();
                    append(label + " exit code: " + exit);
                    context.status(exit == 0 ? label + " complete." : label + " failed.");
                } catch (Exception e) {
                    context.error(label + " failed", e);
                } finally {
                    setButtonsEnabled(true);
                }
            }
        }.execute();
    }

    private void append(String message) {
        output.append(message + System.lineSeparator());
        output.setCaretPosition(output.getDocument().getLength());
    }

    private void setButtonsEnabled(boolean enabled) {
        backupButton.setEnabled(enabled);
        analysisButton.setEnabled(enabled);
    }

    private static String findJava() {
        String javaHome = System.getProperty("java.home");
        if (javaHome == null || javaHome.isBlank()) {
            return "java";
        }

        Path java = Path.of(javaHome, "bin", isWindows() ? "java.exe" : "java");
        return java.toFile().exists() ? java.toString() : "java";
    }

    private static boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase().contains("win");
    }
}
