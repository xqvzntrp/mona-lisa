import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.RowFilter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.TableRowSorter;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.util.List;
import java.util.UUID;

final class LinksViewPanel extends JPanel implements ViewPanel {
    private final AppContext context;
    private final Runnable relationshipsChanged;
    private final LinkTableModel linkModel = new LinkTableModel();
    private final LinkNoteTableModel noteModel = new LinkNoteTableModel();
    private final JTable linkTable = new JTable(linkModel);
    private final JTable noteTable = new JTable(noteModel);
    private final TableRowSorter<LinkTableModel> sorter = new TableRowSorter<>(linkModel);
    private final JTextField search = new JTextField();
    private final JTextArea detail = new JTextArea();

    LinksViewPanel(AppContext context, Runnable relationshipsChanged) {
        super(new BorderLayout());
        this.context = context;
        this.relationshipsChanged = relationshipsChanged;

        linkTable.setRowSorter(sorter);
        linkTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        linkTable.setFillsViewportHeight(true);
        linkTable.getSelectionModel().addListSelectionListener(event -> {
            if (!event.getValueIsAdjusting()) {
                showSelectedLinkDetail();
            }
        });
        linkTable.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent event) {
                if (event.getClickCount() == 2 && linkTable.getSelectedRow() >= 0) {
                    editSelectedLinkRecord();
                }
            }
        });

        noteTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        noteTable.setFillsViewportHeight(true);
        detail.setEditable(false);
        detail.setLineWrap(true);
        detail.setWrapStyleWord(true);
        detail.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        search.putClientProperty("JTextField.placeholderText", "Search links");
        search.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent event) {
                updateLinkFilter();
            }

            @Override
            public void removeUpdate(DocumentEvent event) {
                updateLinkFilter();
            }

            @Override
            public void changedUpdate(DocumentEvent event) {
                updateLinkFilter();
            }
        });

        add(linkActionBar(), BorderLayout.NORTH);
        add(linkContent(), BorderLayout.CENTER);
        refresh();
    }

    @Override
    public String title() {
        return "Links";
    }

    @Override
    public JPanel panel() {
        return this;
    }

    @Override
    public void refresh() {
        refreshLinks(selectedLinkRecordId());
    }

    private JPanel linkActionBar() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        JLabel title = new JLabel("Links");
        title.setFont(title.getFont().deriveFont(20f));

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        JButton refreshButton = new JButton("Refresh");
        JButton addButton = new JButton("Add Link");
        JButton editButton = new JButton("Edit");
        JButton openButton = new JButton("Open");
        JButton deleteButton = new JButton("Delete");

        refreshButton.addActionListener(event -> refresh());
        addButton.addActionListener(event -> addLinkRecord());
        editButton.addActionListener(event -> editSelectedLinkRecord());
        openButton.addActionListener(event -> openSelectedLinkRecord());
        deleteButton.addActionListener(event -> deleteSelectedLinkRecord());

        buttons.add(refreshButton);
        buttons.add(addButton);
        buttons.add(editButton);
        buttons.add(openButton);
        buttons.add(deleteButton);

        panel.add(title, BorderLayout.WEST);
        panel.add(buttons, BorderLayout.EAST);
        return panel;
    }

    private JSplitPane linkContent() {
        JPanel master = new JPanel(new BorderLayout(0, 8));
        master.setBorder(BorderFactory.createEmptyBorder(0, 8, 8, 4));
        master.add(search, BorderLayout.NORTH);
        master.add(new JScrollPane(linkTable), BorderLayout.CENTER);

        JTabbedPane childTabs = new JTabbedPane();
        childTabs.addTab("Notes", linkNotesPanel());

        JSplitPane detailSplit = new JSplitPane(
                JSplitPane.VERTICAL_SPLIT,
                new JScrollPane(detail),
                childTabs
        );
        detailSplit.setResizeWeight(0.58);
        detailSplit.setDividerLocation(290);

        JPanel detailPanel = new JPanel(new BorderLayout());
        detailPanel.setBorder(BorderFactory.createEmptyBorder(0, 4, 8, 8));
        detailPanel.add(detailSplit, BorderLayout.CENTER);

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, master, detailPanel);
        split.setResizeWeight(0.34);
        split.setDividerLocation(340);
        return split;
    }

    private JPanel linkNotesPanel() {
        JPanel panel = tablePanel(noteTable);
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 4));
        JButton assignButton = new JButton("Assign to Note");
        JButton removeButton = new JButton("Remove from Note");

        assignButton.addActionListener(event -> assignSelectedLinkToNote());
        removeButton.addActionListener(event -> removeSelectedLinkFromNote());

        buttons.add(assignButton);
        buttons.add(removeButton);
        panel.add(buttons, BorderLayout.SOUTH);
        return panel;
    }

    private static JPanel tablePanel(JTable table) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        return panel;
    }

    private void updateLinkFilter() {
        String text = search.getText().trim();
        if (text.isEmpty()) {
            sorter.setRowFilter(null);
        } else {
            sorter.setRowFilter(RowFilter.regexFilter("(?i)" + java.util.regex.Pattern.quote(text)));
        }
        showSelectedLinkDetail();
    }

    private void refreshLinks(String selectId) {
        try {
            linkModel.setLinks(context.database().loadLinks());
            if (selectId != null) {
                selectLinkRecord(selectId);
            }
            if (linkTable.getSelectedRow() < 0 && linkTable.getRowCount() > 0) {
                linkTable.setRowSelectionInterval(0, 0);
            }
            showSelectedLinkDetail();
            context.status("Loaded " + linkModel.getRowCount() + " link(s).");
        } catch (Exception e) {
            context.error("Refresh links failed", e);
        }
    }

    private void addLinkRecord() {
        LinkFormDialog dialog = new LinkFormDialog(context.owner(), null);
        LinkFormDialog.Result result = dialog.showDialog();
        if (result == null) {
            return;
        }

        try {
            Link link = new Link(UUID.randomUUID().toString(), result.title(), result.url());
            context.database().upsertLink(link);
            refreshLinks(link.id());
            context.status("Added link.");
        } catch (Exception e) {
            context.error("Add link failed", e);
        }
    }

    private void editSelectedLinkRecord() {
        Link link = selectedLinkRecord();
        if (link == null) {
            return;
        }

        LinkFormDialog dialog = new LinkFormDialog(context.owner(), link);
        LinkFormDialog.Result result = dialog.showDialog();
        if (result == null) {
            return;
        }

        try {
            Link updated = new Link(link.id(), result.title(), result.url());
            context.database().upsertLink(updated);
            refreshLinks(updated.id());
            context.status("Saved link.");
        } catch (Exception e) {
            context.error("Edit link failed", e);
        }
    }

    private void openSelectedLinkRecord() {
        Link link = selectedLinkRecord();
        if (link == null) {
            return;
        }
        context.openUrl(link.url(), link.title());
    }

    private void deleteSelectedLinkRecord() {
        Link link = selectedLinkRecord();
        if (link == null) {
            return;
        }

        int choice = JOptionPane.showConfirmDialog(
                context.owner(),
                "Delete link \"" + AppText.displayTitle(link) + "\"?",
                "Delete link",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.WARNING_MESSAGE
        );
        if (choice != JOptionPane.OK_OPTION) {
            return;
        }

        try {
            context.database().deleteLink(link.id());
            refreshLinks(null);
            relationshipsChanged.run();
            context.status("Deleted link.");
        } catch (Exception e) {
            context.error("Delete link failed", e);
        }
    }

    private void assignSelectedLinkToNote() {
        Link link = selectedLinkRecord();
        if (link == null) {
            return;
        }

        try {
            AssignNoteDialog dialog = new AssignNoteDialog(context.owner(), context.database().loadNotes());
            AssignNoteDialog.Result result = dialog.showDialog();
            if (result == null) {
                return;
            }

            context.database().assignNoteLink(result.noteId(), link.id(), AppClock.now());
            showSelectedLinkDetail();
            relationshipsChanged.run();
            context.status("Assigned note.");
        } catch (Exception e) {
            context.error("Assign note failed", e);
        }
    }

    private void removeSelectedLinkFromNote() {
        Link link = selectedLinkRecord();
        LinkNote note = selectedLinkNote();
        if (link == null || note == null) {
            return;
        }

        int choice = JOptionPane.showConfirmDialog(
                context.owner(),
                "Remove note \"" + AppText.displayTitle(note) + "\" from this link?",
                "Remove note",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.WARNING_MESSAGE
        );
        if (choice != JOptionPane.OK_OPTION) {
            return;
        }

        try {
            context.database().removeNoteLink(note.noteId(), link.id());
            showSelectedLinkDetail();
            relationshipsChanged.run();
            context.status("Removed note.");
        } catch (Exception e) {
            context.error("Remove note failed", e);
        }
    }

    private void showSelectedLinkDetail() {
        Link link = selectedLinkRecord();
        if (link == null) {
            detail.setText("Select a link to view details.");
            noteModel.setRows(List.of());
            return;
        }

        detail.setText("""
                Title: %s
                URL: %s
                """.formatted(AppText.displayTitle(link), link.url()));
        detail.setCaretPosition(0);

        try {
            noteModel.setRows(context.database().loadNotesForLink(link.id()));
        } catch (Exception e) {
            noteModel.setRows(List.of());
            context.error("Load notes for link failed", e);
        }
    }

    private Link selectedLinkRecord() {
        int viewRow = linkTable.getSelectedRow();
        if (viewRow < 0) {
            return null;
        }
        return linkModel.linkAt(linkTable.convertRowIndexToModel(viewRow));
    }

    private LinkNote selectedLinkNote() {
        int viewRow = noteTable.getSelectedRow();
        if (viewRow < 0) {
            return null;
        }
        return noteModel.rowAt(noteTable.convertRowIndexToModel(viewRow));
    }

    private String selectedLinkRecordId() {
        Link link = selectedLinkRecord();
        return link == null ? null : link.id();
    }

    private void selectLinkRecord(String id) {
        for (int modelRow = 0; modelRow < linkModel.getRowCount(); modelRow++) {
            if (linkModel.linkAt(modelRow).id().equals(id)) {
                int viewRow = linkTable.convertRowIndexToView(modelRow);
                if (viewRow >= 0) {
                    linkTable.setRowSelectionInterval(viewRow, viewRow);
                }
                return;
            }
        }
    }
}
