import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Window;

final class ActivityFormDialog extends JDialog implements ModalForm<ActivityFormDialog.Result> {
    private final JTextField typeField = new JTextField(28);
    private final JTextArea textArea = new JTextArea(8, 36);
    private Result result;

    ActivityFormDialog(Window owner, Activity activity) {
        super(owner, activity == null ? "Add Activity" : "Edit Activity", ModalityType.APPLICATION_MODAL);
        setLayout(new BorderLayout(8, 8));

        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        if (activity != null) {
            typeField.setText(activity.activityType());
            textArea.setText(activity.activityText());
        }

        add(fields(), BorderLayout.CENTER);
        add(buttons(), BorderLayout.SOUTH);
        pack();
        setMinimumSize(new Dimension(460, 300));
        setLocationRelativeTo(owner);
    }

    private JPanel fields() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 0, 10));

        GridBagConstraints constraints = new GridBagConstraints();
        constraints.insets = new Insets(0, 0, 8, 0);
        constraints.anchor = GridBagConstraints.WEST;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 0;
        constraints.gridy = 0;
        panel.add(new JLabel("Type"), constraints);

        constraints.gridy = 1;
        constraints.weightx = 1;
        panel.add(typeField, constraints);

        constraints.gridy = 2;
        constraints.weightx = 0;
        panel.add(new JLabel("Text"), constraints);

        constraints.gridy = 3;
        constraints.weightx = 1;
        constraints.weighty = 1;
        constraints.fill = GridBagConstraints.BOTH;
        panel.add(new JScrollPane(textArea), constraints);
        return panel;
    }

    private JPanel buttons() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton saveButton = new JButton("Save");
        JButton cancelButton = new JButton("Cancel");

        saveButton.addActionListener(event -> save());
        cancelButton.addActionListener(event -> dispose());
        getRootPane().setDefaultButton(saveButton);

        panel.add(cancelButton);
        panel.add(saveButton);
        return panel;
    }

    @Override
    public Result showDialog() {
        setVisible(true);
        return result;
    }

    private void save() {
        String activityType = typeField.getText().trim();
        String activityText = textArea.getText().trim();
        if (activityType.isBlank() && activityText.isBlank()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Enter an activity type or text.",
                    "Activity is empty",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        result = new Result(activityType, activityText);
        dispose();
    }

    record Result(String activityType, String activityText) {
    }
}
