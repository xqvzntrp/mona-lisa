import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTabbedPane;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import java.awt.BorderLayout;

public final class NotesFormsApp extends JFrame {
    private final JLabel statusLabel = new JLabel(" ");

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                new NotesFormsApp().setVisible(true);
            } catch (Exception e) {
                AppContext.showStartupError(e);
            }
        });
    }

    private NotesFormsApp() throws Exception {
        super("Notes Forms");
        Database database = Database.open();
        database.ensureSchema();

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        AppContext context = new AppContext(this, database, this::status, this::error);
        NotesViewPanel notesView = new NotesViewPanel(context);
        LinksViewPanel linksView = new LinksViewPanel(context, notesView::refreshSelectedDetails);
        OperationsViewPanel operationsView = new OperationsViewPanel(context);

        JTabbedPane mainTabs = new JTabbedPane();
        mainTabs.addTab(notesView.title(), notesView.panel());
        mainTabs.addTab(linksView.title(), linksView.panel());
        mainTabs.addTab(operationsView.title(), operationsView.panel());

        add(mainTabs, BorderLayout.CENTER);
        add(statusLabel, BorderLayout.SOUTH);

        setSize(1000, 620);
        setLocationRelativeTo(null);
    }

    private void status(String message) {
        statusLabel.setText(" " + message);
    }

    private void error(String title, Exception e) {
        status(title + ": " + e.getMessage());
        JOptionPane.showMessageDialog(this, e.getMessage(), title, JOptionPane.ERROR_MESSAGE);
    }
}
