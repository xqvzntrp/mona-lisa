import java.io.InputStream;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.UUID;

final class Database {
    private static final Path SCHEMA_SQL_PATH = Path.of("sql", "simple-notes-schema.sql");

    private final Connection connection;
    @SuppressWarnings("unused")
    private final URLClassLoader driverLoader;

    private Database(Connection connection, URLClassLoader driverLoader) {
        this.connection = connection;
        this.driverLoader = driverLoader;
    }

    static Database open() throws Exception {
        Properties props = new Properties();
        try (InputStream in = Files.newInputStream(Path.of("sql-runner.local.properties"))) {
            props.load(in);
        }

        Path jar = Path.of("ojdbc11-23.3.0.23.09.jar").toAbsolutePath().normalize();
        URLClassLoader loader = new URLClassLoader(new URL[]{jar.toUri().toURL()}, Database.class.getClassLoader());
        Driver driver = (Driver) Class.forName("oracle.jdbc.OracleDriver", true, loader)
                .getDeclaredConstructor()
                .newInstance();

        Properties jdbcProps = new Properties();
        jdbcProps.setProperty("user", require(props, "SQL_RUNNER_JDBC_USER"));
        jdbcProps.setProperty("password", require(props, "SQL_RUNNER_JDBC_PASSWORD"));
        Connection connection = driver.connect(require(props, "SQL_RUNNER_JDBC_URL"), jdbcProps);
        connection.setAutoCommit(true);
        return new Database(connection, loader);
    }

    void ensureSchema() throws Exception {
        Path jar = Path.of("sql-runner-1.0-SNAPSHOT.jar").toAbsolutePath().normalize();
        try (URLClassLoader loader = new URLClassLoader(
                new URL[]{jar.toUri().toURL()},
                Database.class.getClassLoader()
        )) {
            Class<?> runnerClass = Class.forName("local.dev.sql.runner.SqlFileRunner", true, loader);
            Object runner = runnerClass.getConstructor(Connection.class).newInstance(connection);
            runnerClass.getMethod("executeFile", Path.class).invoke(runner, SCHEMA_SQL_PATH);
        }
    }

    List<Note> loadNotes() throws SQLException {
        List<Note> notes = new ArrayList<>();
        try (Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery("""
                     SELECT ID, TITLE, BODY, CREATED_AT, UPDATED_AT
                     FROM SIMPLE_NOTES
                     ORDER BY UPDATED_AT DESC
                     """)) {
            while (rs.next()) {
                notes.add(new Note(
                        rs.getString("ID"),
                        value(rs.getString("TITLE")),
                        value(rs.getString("BODY")),
                        value(rs.getString("CREATED_AT")),
                        value(rs.getString("UPDATED_AT"))
                ));
            }
        }
        return notes;
    }

    void upsertNote(Note note) throws SQLException {
        try (PreparedStatement update = connection.prepareStatement("""
                UPDATE SIMPLE_NOTES
                SET TITLE = ?, BODY = ?, CREATED_AT = ?, UPDATED_AT = ?
                WHERE ID = ?
                """)) {
            update.setString(1, note.title());
            update.setString(2, note.body());
            update.setString(3, note.createdAt());
            update.setString(4, note.updatedAt());
            update.setString(5, note.id());
            if (update.executeUpdate() > 0) {
                return;
            }
        }

        try (PreparedStatement insert = connection.prepareStatement("""
                INSERT INTO SIMPLE_NOTES (ID, TITLE, BODY, CREATED_AT, UPDATED_AT)
                VALUES (?, ?, ?, ?, ?)
                """)) {
            insert.setString(1, note.id());
            insert.setString(2, note.title());
            insert.setString(3, note.body());
            insert.setString(4, note.createdAt());
            insert.setString(5, note.updatedAt());
            insert.executeUpdate();
        }
    }

    void deleteNote(String id) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("DELETE FROM SIMPLE_NOTES WHERE ID = ?")) {
            statement.setString(1, id);
            statement.executeUpdate();
        }
    }

    List<AssignedLink> loadAssignedLinks(String noteId) throws SQLException {
        List<AssignedLink> links = new ArrayList<>();
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT l.ID, l.TITLE, l.URL, nl.CREATED_AT
                FROM SIMPLE_NOTE_LINKS nl
                JOIN SIMPLE_LINKS l ON l.ID = nl.LINK_ID
                WHERE nl.NOTE_ID = ?
                ORDER BY l.TITLE
                """)) {
            statement.setString(1, noteId);
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    links.add(new AssignedLink(
                            value(rs.getString("ID")),
                            value(rs.getString("TITLE")),
                            value(rs.getString("URL")),
                            value(rs.getString("CREATED_AT"))
                    ));
                }
            }
        }
        return links;
    }

    List<Link> loadLinks() throws SQLException {
        List<Link> links = new ArrayList<>();
        try (Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery("""
                     SELECT ID, TITLE, URL
                     FROM SIMPLE_LINKS
                     ORDER BY TITLE
                     """)) {
            while (rs.next()) {
                links.add(new Link(
                        value(rs.getString("ID")),
                        value(rs.getString("TITLE")),
                        value(rs.getString("URL"))
                ));
            }
        }
        return links;
    }

    void upsertLink(Link link) throws SQLException {
        String now = AppClock.now();
        try (PreparedStatement update = connection.prepareStatement("""
                UPDATE SIMPLE_LINKS
                SET TITLE = ?, URL = ?, UPDATED_AT = ?
                WHERE ID = ?
                """)) {
            update.setString(1, link.title());
            update.setString(2, link.url());
            update.setString(3, now);
            update.setString(4, link.id());
            if (update.executeUpdate() > 0) {
                return;
            }
        }

        try (PreparedStatement insert = connection.prepareStatement("""
                INSERT INTO SIMPLE_LINKS (ID, TITLE, URL, CREATED_AT, UPDATED_AT)
                VALUES (?, ?, ?, ?, ?)
                """)) {
            insert.setString(1, link.id());
            insert.setString(2, link.title());
            insert.setString(3, link.url());
            insert.setString(4, now);
            insert.setString(5, now);
            insert.executeUpdate();
        }
    }

    void deleteLink(String id) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("DELETE FROM SIMPLE_LINKS WHERE ID = ?")) {
            statement.setString(1, id);
            statement.executeUpdate();
        }
    }

    List<LinkNote> loadNotesForLink(String linkId) throws SQLException {
        List<LinkNote> rows = new ArrayList<>();
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT n.ID, n.TITLE, n.UPDATED_AT, nl.CREATED_AT AS ASSIGNED_AT
                FROM SIMPLE_NOTE_LINKS nl
                JOIN SIMPLE_NOTES n ON n.ID = nl.NOTE_ID
                WHERE nl.LINK_ID = ?
                ORDER BY n.UPDATED_AT DESC
                """)) {
            statement.setString(1, linkId);
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    rows.add(new LinkNote(
                            value(rs.getString("ID")),
                            value(rs.getString("TITLE")),
                            value(rs.getString("UPDATED_AT")),
                            value(rs.getString("ASSIGNED_AT"))
                    ));
                }
            }
        }
        return rows;
    }

    void assignNoteLink(String noteId, String linkId, String createdAt) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("""
                INSERT INTO SIMPLE_NOTE_LINKS (ID, NOTE_ID, LINK_ID, CREATED_AT)
                VALUES (?, ?, ?, ?)
                """)) {
            statement.setString(1, UUID.randomUUID().toString());
            statement.setString(2, noteId);
            statement.setString(3, linkId);
            statement.setString(4, createdAt);
            statement.executeUpdate();
        } catch (SQLException e) {
            if (e.getErrorCode() != 1) {
                throw e;
            }
        }
    }

    void removeNoteLink(String noteId, String linkId) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("""
                DELETE FROM SIMPLE_NOTE_LINKS
                WHERE NOTE_ID = ? AND LINK_ID = ?
                """)) {
            statement.setString(1, noteId);
            statement.setString(2, linkId);
            statement.executeUpdate();
        }
    }

    List<Activity> loadActivities(String noteId) throws SQLException {
        List<Activity> activities = new ArrayList<>();
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT ID, ACTIVITY_TYPE, ACTIVITY_TEXT, CREATED_AT, UPDATED_AT
                FROM SIMPLE_NOTE_ACTIVITIES
                WHERE NOTE_ID = ?
                ORDER BY UPDATED_AT DESC
                """)) {
            statement.setString(1, noteId);
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    activities.add(new Activity(
                            value(rs.getString("ID")),
                            noteId,
                            value(rs.getString("ACTIVITY_TYPE")),
                            value(rs.getString("ACTIVITY_TEXT")),
                            value(rs.getString("CREATED_AT")),
                            value(rs.getString("UPDATED_AT"))
                    ));
                }
            }
        }
        return activities;
    }

    void upsertActivity(Activity activity) throws SQLException {
        try (PreparedStatement update = connection.prepareStatement("""
                UPDATE SIMPLE_NOTE_ACTIVITIES
                SET NOTE_ID = ?, ACTIVITY_TYPE = ?, ACTIVITY_TEXT = ?, CREATED_AT = ?, UPDATED_AT = ?
                WHERE ID = ?
                """)) {
            update.setString(1, activity.noteId());
            update.setString(2, activity.activityType());
            update.setString(3, activity.activityText());
            update.setString(4, activity.createdAt());
            update.setString(5, activity.updatedAt());
            update.setString(6, activity.id());
            if (update.executeUpdate() > 0) {
                return;
            }
        }

        try (PreparedStatement insert = connection.prepareStatement("""
                INSERT INTO SIMPLE_NOTE_ACTIVITIES
                    (ID, NOTE_ID, ACTIVITY_TYPE, ACTIVITY_TEXT, CREATED_AT, UPDATED_AT)
                VALUES (?, ?, ?, ?, ?, ?)
                """)) {
            insert.setString(1, activity.id());
            insert.setString(2, activity.noteId());
            insert.setString(3, activity.activityType());
            insert.setString(4, activity.activityText());
            insert.setString(5, activity.createdAt());
            insert.setString(6, activity.updatedAt());
            insert.executeUpdate();
        }
    }

    void deleteActivity(String id) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(
                "DELETE FROM SIMPLE_NOTE_ACTIVITIES WHERE ID = ?"
        )) {
            statement.setString(1, id);
            statement.executeUpdate();
        }
    }

    private static String require(Properties props, String name) {
        String value = props.getProperty(name);
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException("Missing property: " + name);
        }
        return value.trim();
    }

    private static String value(String value) {
        return value == null ? "" : value;
    }

}
