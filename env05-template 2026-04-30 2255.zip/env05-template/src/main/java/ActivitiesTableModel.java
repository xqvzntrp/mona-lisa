import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;

final class ActivitiesTableModel extends AbstractTableModel {
    private static final List<String> COLUMNS = List.of("Type", "Text", "Updated");
    private final List<Activity> activities = new ArrayList<>();

    void setActivities(List<Activity> loaded) {
        activities.clear();
        activities.addAll(loaded);
        fireTableDataChanged();
    }

    Activity activityAt(int row) {
        return activities.get(row);
    }

    @Override
    public int getRowCount() {
        return activities.size();
    }

    @Override
    public int getColumnCount() {
        return COLUMNS.size();
    }

    @Override
    public String getColumnName(int column) {
        return COLUMNS.get(column);
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Activity activity = activities.get(rowIndex);
        return switch (columnIndex) {
            case 0 -> activity.activityType();
            case 1 -> activity.activityText();
            case 2 -> activity.updatedAt();
            default -> "";
        };
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return false;
    }
}
