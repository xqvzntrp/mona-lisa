import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Window;

final class LinkFormDialog extends JDialog implements ModalForm<LinkFormDialog.Result> {
    private final JTextField titleField = new JTextField(36);
    private final JTextField urlField = new JTextField(36);
    private Result result;

    LinkFormDialog(Window owner, Link link) {
        super(owner, link == null ? "Add Link" : "Edit Link", ModalityType.APPLICATION_MODAL);
        setLayout(new BorderLayout(8, 8));

        if (link != null) {
            titleField.setText(link.title());
            urlField.setText(link.url());
        }

        add(fields(), BorderLayout.CENTER);
        add(buttons(), BorderLayout.SOUTH);
        pack();
        setMinimumSize(new Dimension(520, 210));
        setLocationRelativeTo(owner);
    }

    private JPanel fields() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 0, 10));

        GridBagConstraints constraints = new GridBagConstraints();
        constraints.insets = new Insets(0, 0, 8, 0);
        constraints.anchor = GridBagConstraints.WEST;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 0;
        constraints.gridy = 0;
        panel.add(new JLabel("Title"), constraints);

        constraints.gridy = 1;
        constraints.weightx = 1;
        panel.add(titleField, constraints);

        constraints.gridy = 2;
        constraints.weightx = 0;
        panel.add(new JLabel("URL"), constraints);

        constraints.gridy = 3;
        constraints.weightx = 1;
        panel.add(urlField, constraints);
        return panel;
    }

    private JPanel buttons() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton saveButton = new JButton("Save");
        JButton cancelButton = new JButton("Cancel");

        saveButton.addActionListener(event -> save());
        cancelButton.addActionListener(event -> dispose());
        getRootPane().setDefaultButton(saveButton);

        panel.add(cancelButton);
        panel.add(saveButton);
        return panel;
    }

    @Override
    public Result showDialog() {
        setVisible(true);
        return result;
    }

    private void save() {
        String title = titleField.getText().trim();
        String url = urlField.getText().trim();
        if (title.isBlank() && url.isBlank()) {
            JOptionPane.showMessageDialog(this, "Enter a title or URL.", "Link is empty", JOptionPane.WARNING_MESSAGE);
            return;
        }

        result = new Result(title, url);
        dispose();
    }

    record Result(String title, String url) {
    }
}
