record LinkNote(String noteId, String title, String updatedAt, String assignedAt) {
}
