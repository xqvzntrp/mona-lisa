final class AppText {
    private AppText() {
    }

    static String displayTitle(Note note) {
        return note.title().isBlank() ? "(Untitled)" : note.title();
    }

    static String displayTitle(AssignedLink link) {
        return link.title().isBlank() ? "(Untitled)" : link.title();
    }

    static String displayTitle(Link link) {
        return link.title().isBlank() ? "(Untitled)" : link.title();
    }

    static String displayTitle(LinkNote note) {
        return note.title().isBlank() ? "(Untitled)" : note.title();
    }
}
