import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;

final class LinkTableModel extends AbstractTableModel {
    private static final List<String> COLUMNS = List.of("Title", "URL");
    private final List<Link> links = new ArrayList<>();

    void setLinks(List<Link> loaded) {
        links.clear();
        links.addAll(loaded);
        fireTableDataChanged();
    }

    Link linkAt(int row) {
        return links.get(row);
    }

    @Override
    public int getRowCount() {
        return links.size();
    }

    @Override
    public int getColumnCount() {
        return COLUMNS.size();
    }

    @Override
    public String getColumnName(int column) {
        return COLUMNS.get(column);
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Link link = links.get(rowIndex);
        return switch (columnIndex) {
            case 0 -> link.title();
            case 1 -> link.url();
            default -> "";
        };
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return false;
    }
}
